int main() {

int f = 0;
float y = 1.2;
char c = 'c';
y + c;
f + c;
c + f;
y  + f;

}