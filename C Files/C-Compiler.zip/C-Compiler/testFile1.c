int main() {

	int total = 1;
	int i;
	int fact = 10;

	for(i = 1; i < fact + 1; i = i + 1 ) {
		total = total * i;
	}
}