int main(){

int x = 23;
char x = 'l';


}
