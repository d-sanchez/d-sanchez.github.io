int main() {

	int i = 0;
	int j = 2;
	int k = 3;
	int m;

	i = j + k / m - 5 * i + 3 - 1;
}