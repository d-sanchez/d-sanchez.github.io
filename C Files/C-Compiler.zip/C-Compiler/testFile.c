int main() {
int i = 0;
int l = 0;
i = 2;
l = 3;



}