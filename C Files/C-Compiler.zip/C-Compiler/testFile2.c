int main(){

int x = 23;
r = 24;

}
